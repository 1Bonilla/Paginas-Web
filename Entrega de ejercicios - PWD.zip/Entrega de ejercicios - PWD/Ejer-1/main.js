const form = document.querySelector("form");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const nombre = document.querySelector("input[name='nombre']").value;
  const correo = document.querySelector("input[name='correo']").value;
  const edad = document.querySelector("input[name='edad']").value;
  const fechaNacimiento = document.querySelector("input[name='fecha_nacimiento']").value;
  const sexo = document.querySelector("input[name='sexo']:checked").value;

  const nuevaPestaña = window.open("", "registro", "width=400,height=200");
  nuevaPestaña.document.write(`
    Nombre: ${nombre}
    Correo: ${correo}
    Edad: ${edad}
    Fecha de nacimiento: ${fechaNacimiento}
    Sexo: ${sexo}
  `);
});
