const form = document.getElementById("miFormulario");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const departamento = document.getElementById("departamento").value;
  const genero = document.getElementById("genero").value;
  const educacion = document.getElementById("educacion").value;

  console.log("Departamento:", departamento);
  console.log("Género:", genero);
  console.log("Educación:", educacion);
});

document.getElementById("departamento").addEventListener("change", function (e) {
  actualizarValor("departamento", e);
});

document.getElementById("genero").addEventListener("change", function (e) {
  actualizarValor("genero", e);
});

document.getElementById("educacion").addEventListener("change", function (e) {
  actualizarValor("educacion", e);
});

function actualizarValor(nombreCampo, evento) {
  const option = evento.target.options[evento.target.selectedIndex];
  document.getElementById(nombreCampo).value = option.value;
}
