const form = document.querySelector("form");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const nombre = document.querySelector("input[name='nombre']");
  const dui = document.querySelector("input[name='dui']");
  const fechaNacimiento = document.querySelector("input[name='fecha_nacimiento']");
  const genero = document.querySelector("input[name='genero']:checked");
  const departamento = document.querySelector("select[name='departamento']");

  aplicarEstilo(nombre);
  aplicarEstilo(dui);
  aplicarEstilo(fechaNacimiento);
  aplicarEstilo(genero);
  aplicarEstilo(departamento);
});

function aplicarEstilo(elemento) {
  elemento.style.backgroundColor = elemento.value ? "white" : "gray";
}
